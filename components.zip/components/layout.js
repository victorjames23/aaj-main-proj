import Slider from "react-slick";
import logo from "../images/1.jpg"
const Layout = () => {
 const settings = {
  dots: true,
  infinite: true,
  speed: 500,
  slidesToShow:1,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 3000,
  pauseOnHover: true // prevent pausing on hover
};
 return ( <>
 <Slider  {...settings}>
  <div className="my-mother my-bottom-50"> 
  <div className=""><span className="px40 xs-px30 faded">Listen to “RETIRE EARLY” Podcast Daily.</span> </div>
   <div className="my-col-10 down-2 off-1 xs-12 xs-down-3">
    <a href='https://shorturl.at/enHJ6'>  <span className="btn-sm-2 bold bg-white black">Listen Now</span></a>
   </div>
  </div>
  <div className="my-mother my-bottom-50 bg-fded "> 
  <div className=""><span className="px50 xs-px30 faded">Join “RETIRE EARLY” Virtual Internship.</span> </div>
   <div className="my-col-10 down-2 off-1 xs-12 xs-down-3">
    <a href='https://selar.co/reinternship'>  <span className="btn-sm-2 bold bg-white black">Join Now</span></a>
   </div>
  </div>
  <div className="my-mother my-bottom-50 bg-fded "> 
  <div className=""><span className="px50 xs-px30 faded">Attend Chat & Dine With Value Investors (April)</span> </div>
   <div className="my-col-10 down-2 off-1 xs-12 xs-down-3">
    <a href='https://selar.co/aajdinner'>  <span className="btn-sm-2 bold bg-white black">Join Now</span></a>
   </div>
  </div>
  <div className="my-mother my-bottom-50 bg-fded "> 
  <div className=""><span className="px50 xs-px30 faded">Attend “Retire Early” Live Webinar Every Saturday</span> </div>
   <div className="my-col-10 down-2 off-1 xs-12 xs-down-3">
   <a href='https://selar.co/retireearlylive'>  <span className="btn-sm-2 bold bg-white black">Join Now</span></a>
   </div>
  </div>

 </Slider>
 </> );
}
 
export default Layout;