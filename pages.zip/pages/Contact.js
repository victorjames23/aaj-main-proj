import {useState}  from 'react';

const Contact =() => {
    const formInitialDetails = {
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        message: ''
    }

    const [formDetails, setFormDetails] = useState(formInitialDetails);
    const [buttonText, setButtonText] = useState('send');
    const [status, setStatus] = useState({});

    const onFormUpdate = (category, value) => {
        setFormDetails({
            ...formDetails,
            [category]: value,
        })
    }

    const handleSubmit = async (e) => {
        e.preventDefault();
        setButtonText('Sending...');
        let response = await fetch("", {
            method: "post",
            headers: {
                "Content-Type": "Application/json;charset=utf-8",
            },
            body: JSON.stringify(formDetails), 
        });
        setButtonText("Send");
        let result = response.json();
        setFormDetails(formInitialDetails);
        if (result.code === 200) {
            setStatus({ success: true, message: 'Message sent sucessfull'});
        } else {
            setStatus({ success: false, message: 'something went wrong pls try again leter.'})
        }
    };

    return(
        <section className='contact' id='connect'>
            <container className="my-container bg-color-code-2 ">
                <Row className="align-item-center">
                        <Col>
                        <h2>GET IN TOUCH</h2>
                        <form onSubmit={handleSubmit}>
                            <Row>
                                <Col sm={6} className="px8">
                                <input type="text" className="input" value={formDetails.firstName} onChange={(e) => onFormUpdate('firstName', e.target.value)} placeholder="First Name" />
                                </Col>
                                <Col sm={6} className="px8">
                                <input type="text" className="input" value={formDetails.lastName} onChange={(e) => onFormUpdate('lastName', e.target.value)} placeholder="Last Name" />
                                </Col>
                                <Col sm={6} className="px8">
                                <input type="email" className="input" value={formDetails.email} onChange={(e) => onFormUpdate('email', e.target.value)} placeholder="Email Address" />
                                </Col>
                                <Col sm={6} className="px8">
                                <input type="tel" className="input" value={formDetails.phone} onChange={(e) => onFormUpdate('phone', e.target.value)} placeholder="Phone no." />
                                </Col>
                                <Col sm={6} className="px8">
                                <input type="text" className="input" value={formDetails.message} onChange={(e) => onFormUpdate('message', e.target.value)} placeholder="Investment Plan" />
                                <button className="btn-explore button c-pointer" type="submit"><span>{buttonText}</span></button>
                                </Col>
                                (
                                    status.message &&
                                    <Col>
                                    <p className={status.success === false ? "danger" : "success"}>{status.message}</p>
                                    </Col>
                                )
                            </Row>
                        </form>
                        </Col>
                </Row>
            </container>
        </section>
    )
}

export default Contact;