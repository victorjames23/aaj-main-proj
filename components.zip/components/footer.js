import { useHistory } from "react-router-dom";
import useUtils from "../utils/useutiles";
import { AiOutlinePhone } from "react-icons/ai";
const Footer = () => {
  const history = useHistory()
  const {openModal} = useUtils()
  return ( <>
  <div className="my-mother my-bottom-50 bg-black xs-centered  hidden-xs">
      <div className="my-col-10 off-1 down-5">
      <div className="my-col-3 px13">
      <div className="my-logo"></div>
      <div className="my-mother down-50">
        <span className="faded bold px13">Dream Bigger, Retire Early</span>
        <div><span className="faded bold px13">© 2023. All Rights Reserved</span></div>
      </div>
      </div>
      <div className="my-col-3 faded px13">
      <div><span>REACH US</span></div>
      <div className="my-mother down-20 c-pointer xs-down-10 px13"><span>ADESINA ADEDEJI JOHN</span></div>
      <div className="my-mother down-4 c-pointer px13"><span> <i className="fas fa-phone"></i> +234 8053323987, +234 8108302443</span></div>
      <div className="my-mother down-4 c-pointer px13"><span><i className="fas fa-envelope"></i> contactaajrealty@gmail.com, info@adesinaadedejijohn.com</span></div>
      <div className="my-mother down-4 c-pointer px13"><span><i className="fas fa-map-marker-alt"></i> Plot 051,  AAJ HQ, River Park Estate, Airport Road, Abuja</span></div>
      </div>
      <div className="my-col-3 faded px13">
      <div><span>QUICK LINKS</span></div>
      <div className="my-col-4 xs-4 down-20">
        <div className="my-mother down-5 c-pointer"><span onClick={()=>{history.push('/')}}>HOME</span></div>
        <div className="my-mother down-5 c-pointer"><span onClick={()=>{history.push('/offers')}}>BUY</span></div>
        <div className="my-mother down-5 c-pointer"><span onClick={()=>{history.push('/offers')}}>RENT</span></div>
      </div>
      <div className="my-col-6 xs-6 down-20">
        <div className="my-mother down-5 c-pointer"><span onClick={()=> {openModal('contact-us')}}>CONTACT </span></div>
        <a href="https://linktr.ee/adesinaadedejijohn"><div className="my-mother down-5 c-pointer"><span>NEWS AND MEDIA</span></div></a>
        <div className="my-mother down-5 c-pointer"><span onClick={()=>{history.push('/about')}}>ABOUT</span></div>
      </div>
      </div>
      <div className="my-col-3 faded px13">
      <div className="my-mother"><span>FOLLOW US</span></div>
      <div className="my-mother down-20">
        <a href="https://facebook.com/adesinaadedejijohn"><span className="pd-10"><i className="fab fa-facebook"></i></span></a>
        <a href="https://www.linkedin.com/company/adesinaadedejirealty/"><span className="pd-10"><i className="fab fa-linkedin"></i></span></a>
        <a href="https://linktr.ee/adesinaadedejijohn"><span className="pd-10"><i className="fa fa-podcast"></i></span></a>
        <a href="https://twitter.com/aajrealty"><span className="pd-10"><i className="fab fa-twitter"></i></span></a>
        <a href="https://www.tiktok.com/@adesinaadedejijohn"><span className="pd-10"><i className="fab fa-tiktok"></i></span></a>
        <a href="https://instagram.com/adesinaadedejijohn"><span className="pd-10"><i className="fab fa-instagram"></i></span></a>
      </div>
      <div className="my-mother down-6 c-pointer"><span>PRIVACY POLICY</span></div>
      <div className="my-mother down-5 c-pointer"><span>TERMS OF USE</span></div>
      </div>
      </div>
      <div className="my-col-10 off-1 down-5">
      <div className="my-col-2 down-2"><span className="faded px13">A DEVELOPMENT OF : </span></div>
      <div className="my-col-3">
      <div className="my-col-1 down-6"> <span className="faded-2">aaj</span></div>
      <div className="my-col-6 mgl-20 px13 faded">   <span>Adesina <br /> Adedeji <br /> John </span></div>
      </div>
      </div>
    </div> 
    
    <div className="hidden-ls my-mother my-bottom-10 xs-down-1vh ">
    <div className="xs-10 xs-off-1 xs-down-15 faded centered">
      <div className="my-mother px30"><span className="bold">REACH US</span></div>
      {/* <div className="my-mother xs-down-10 c-pointer xs-down-10 px13 bold"><span>ADESINA ADEDEJI JOHN</span></div> */}
      <div className="my-mother xs-down-5 bold c-pointer xs-down-10 px13"> 
      <div className="mother"><i className="fas fa-phone px20"></i></div>
      <div className="mother xs-down-5"><span className="mgl-20"> +234 80 533 23 987, +234 81 083 02 443</span></div>
      </div>
      <div className="my-mother xs-down-5 bold c-pointer xs-down-10 px13"> 
      <div className="mother"><i className="fas fa-envelope px20"></i></div>
      <div className="mother xs-down-5"><span className="mgl-20">contactaajrealty@gmail.com, info@adesinaadedejijohn.com</span></div>
      </div>
      <div className="my-mother xs-down-5 bold c-pointer xs-down-10 px13"> 
      <div className="mother"><i className="fas fa-map-marker-alt px20"></i></div>
      <div className="xs-10 xs-off-1 xs-down-5"><span className="mgl-20"> Plot 051,  AAJ HQ, River Park Estate, Airport Road, Abuja</span></div>
      </div>
    </div>
    <div className="xs-10 xs-off-1 xs-down-20 faded centered">
    <div className="my-mother"><span className="bold px30">FOLLOW US</span></div>
      <div className="my-mother xs-down-10 mgl-10">
      <a href="https://facebook.com/adesinaadedejijohn"><span className="pd-10"><i className="fab fa-facebook"></i></span></a>
        <a href="https://www.linkedin.com/company/adesinaadedejirealty/"><span className="pd-10"><i className="fab fa-linkedin"></i></span></a>
        <a href="https://linktr.ee/adesinaadedejijohn"><span className="pd-10"><i className="fa fa-podcast"></i></span></a>
        <a href="https://twitter.com/aajrealty"><span className="pd-10"><i className="fab fa-twitter"></i></span></a>
        <a href="https://www.tiktok.com/@adesinaadedejijohn"><span className="pd-10"><i className="fab fa-tiktok"></i></span></a>
        <a href="https://instagram.com/adesinaadedejijohn"><span className="pd-10"><i className="fab fa-instagram"></i></span></a>
      </div>
    </div>

    <div className="xs-10 xs-off-1 xs-down-5 centered xs-down-20">
      <div className=""><span className="faded bold px30">QUICK LINKS</span></div>
      <div className="my-mother xs-down-10 faded">
      <div className="xs-6 down-20 px13" >
        <div className="my-mother c-pointer xs-down-10"><span className="px13 bold" onClick={()=>{history.push('/')}}>HOME</span></div>
        <div className="my-mother c-pointer xs-down-10"><span className="px13 bold" onClick={()=>{history.push('/offers')}}>BUY</span></div>
        <div className="my-mother c-pointer xs-down-10"><span className="px13 bold" onClick={()=>{history.push('/offers')}}>RENT</span></div>
      </div>
      <div className="xs-6">
        <div className="my-mother c-pointer xs-down-8"><span className="px13 bold" onClick={()=> {openModal('contact-us')}}>CONTACT</span></div>
        <a href="https://linktr.ee/adesinaadedejijohn">
        <div className="my-mother c-pointer xs-down-10"><span className="px13 bold">NEWS AND MEDIA</span></div>
        </a>
        <div className="my-mother c-pointer xs-down-10"><span className="px13 bold"  onClick={()=>{history.push('/about')}}>ABOUT</span></div>
      </div>
      </div>
    </div>
    <div className="my-mother xs-down-10 c-pointer xs-down-10 centered white px30"><span className="bold">PRIVACY POLICY</span></div>
      <div className="my-mother xs-down-2 c-pointer centered faded xs-down-5"><span className="px13 bold">TERMS OF USE</span></div>


    </div>
    <div className="my-mother xs-down-20 centered hidden-ls">
    <span className="faded px13">Dream Bigger, Retire Early</span>
    <div><span className="xs-px13 faded">ADESINA ADEDEJI JOHN</span></div>
    <div className="my-mother xs-down-10"><span className="faded bold px13">© 2023. All Rights Reserved</span></div>
    </div>

  </> );
  }
  
  export default Footer;