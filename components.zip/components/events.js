import Nav from "./nav";
import img2 from '../images/eff.jpeg'
import { useEffect } from "react";
import Footer from "./footer";
import { useRef } from "react";
import { useState } from "react";
import axios from "axios";

const Events = () => {
  const [country, setCountry] = useState([])
  const divRef = useRef(0)
  const handleClick = () => {
   divRef.current.scrollIntoView({ behavior: 'smooth' });
  };
  const [details, setDetails] = useState({
    name:"",
    phone:"",
    email:"",
    country:""
  });

  useEffect(() => {
    document.title = '1% investment'
  })

  const getCountry = async () => {
   try {
    const res = await axios.get('https://raw.githubusercontent.com/samayo/country-json/master/src/country-by-name.json');
    const data = await res.data;
    setCountry(data)
   } catch (error) {
    setTimeout(() => {
      getCountry();
    }, 2000)
   }
  }

  // const submitDetails = async () => {
  //   const formData = new FormData();
  //   formData.append('name', details?.name)
  //   formData.append('phone', details?.phone)
  //   formData.append('email', details?.email)
  //   formData.append('country', details?.country)
  //   const details  = {
  //     method: 'post',
  //     data:formData,
  //     header:{}
  //   }
  //   try {
  //    const res = await axios.post('submitform');
  //    const data = await res.data;
  //    setCountry(data)
  //   } catch (error) {
  //    setTimeout(() => {
  //      getCountry();
  //    }, 2000)
  //   }
  //  }
 
  useEffect(() => {
    getCountry();
  }, [])




  const toWhatsapp = (e) => {
   e.preventDefault();
   window.open(`https://api.whatsapp.com/send?phone=2348120777034&text=Hello%2C%20I%20just%20signed%20up%20for%20the%201%25%20Investing%20Exclusive%20Discussion.%0A%0AMy%20name%20is%20:%20 `)
  }


  return ( <>
   <div className="my-mother my-bottom-50">
   <div className="my-mother"><Nav/></div>
    <div className="my-col-10 off-1 centered xs-10 xs-off-1 down-10 xs-down-15vh">
      <div className="px20 bold centered alice"><span className="focus color-code-1">Join the Exclusive Conversation with fellow 1% Investors</span></div>
      <div className="my-mother bold centered alice down-2 xs-down-3">An Exclusive Virtual Discussion</div>
      <div className="my-mother down-3 xs-down-5 xs-down-15">
        <div className="my-mother"><span className="px50 xs-px30 bold color-code-1"><span className="white">The</span> Multiplier <span className="white">Effect ...</span></span></div>
       <div className="my-col-10 off-1 down-1 px13 alice xs-down-5 xs-12">
       Here’s an avenue to learn and explore opportunities to help you apply "The Multiplier Effect" in today's economy, irrespective of your career or industry. The conversation is a forum to share valuable, uncommon insights into the available opportunities and prospects to harness, especially in the Nigerian economy. The forum is a great avenue to learn from fellow accomplished individuals and review opportunities together.
        <p className="my-mother down-3 xs-down-5"><span className="focus rad-10 color-code-1 px13 bold">Mark your calendars for 29th July 2023</span></p>
        </div>
         <div className="my-mother down-3 xs-down-8">
          <span className="register bg-color-code-s1 white bold c-pointer fa-beat-fade" onClick={handleClick}>Click Here to Register</span>
          {/* <span className="register bg-color-code-s1 white bold c-pointer mgl-20">See Advert <i className="fas fa-video"></i></span> */}
        </div>
          <div className="my-mother centered alice down-4 xs-down-8"><span>See flyer below for more details</span></div>
         <div className="my-mother down-3 xs-down-5">
        <div className="img-container-2"><img src={img2} alt="" /></div>
       </div>
       <div className="my-mother down-5 xs-down-15 left" ref={divRef} >
        <div className="my-mother down-1 centered"><span className="white px20 bold upper-case">Registration Form</span></div>
        <div className="my-col-4 off-4">
        <form  onSubmit={(e) => {toWhatsapp(e)}} >
        <div className="my-col-12 xs-12">
        <div className="my-col-12 xs-12 down-3 xs-down-5 white px13">
          <div className="my-col-12 xs-12 down-3 xs-down-5 white px13">
           <span>Fullname</span>
            <div><input type="text" required onChange={(e) => setDetails(prev => ({...prev, name:e.target.value}))}  className="input" /></div>
          </div>
            <div className="my-col-12 xs-12 down-3 xs-down-5">
            <span>Country</span>
              <select name="" id="" required onChange={(e) => setDetails(prev => ({...prev, country:e.target.value}))} className="input bg-black">
                <option value="">....</option>
                {country?.map((i, index) => (
                <option value={i.country}>{i.country}</option>
                ))}
              </select>
            </div>
          </div>
          <div className="my-col-12 xs-12 down-3 xs-down-5 white px13">
            <span>Email</span>
            <div><input type="email" required onChange={(e) => setDetails(prev => ({...prev, email:e.target.value}))}  className="input" /></div>
          </div>
          <div className="my-col-12 xs-12 down-3 xs-down-5 white px13">
            <span>Phone Number</span>
            <div><input type="tel" required onChange={(e) => setDetails(prev => ({...prev, phone:e.target.value}))}  className="input" /></div>
          </div>
        </div>
        <div className="my-mother down-2 xs-down-10">
          <button className="bg-color-code-s1 my-mother centered white px13 btns" >Register</button>
        </div>
        </form>
        </div>
       </div>
      </div>
    </div>
   </div>
   <Footer/>
  </> );
}
 
export default Events;