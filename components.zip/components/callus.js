const CallUs = () => {
 return ( 
  <div className="my-mother">
    <div className="my-mother my-bottom-10">
     <div className="call-img down-3"></div>
     <div className="col-10 off-1 down-2">
      <div className="my-mother down-5 bold color-code-1 px13">Place a call right away</div>
      <div className="col-5 pd-30 faded bg-color-code-1 down-2 px13"><a href="tel:+2348053323987"><i className="fas fa-phone "></i> Call Us</a> </div>
     </div>
    </div>
  </div>
  );
}
 
export default CallUs;