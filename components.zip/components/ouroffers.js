import { useState } from 'react';
import { AiOutlineLaptop, AiOutlineMail, AiOutlinePhone, AiOutlineWhatsApp } from 'react-icons/ai';
import logo from '../images/logoT.svg';
import useUtils from '../utils/useutiles';
const OurOffers = () => {
  const {closeModal, isSending, setToast, requestMaker} = useUtils();
  const [contact, setContact] = useState(false);
  const [sent, setSent] = useState(false);
  const [details, setDetails] = useState({
    fullname:"",
    email:"",
    phonenumber:"",
    message:""
  })

  const HandleSubmitMessage = async() => {
    if(Object.values(details).every(i => i == '')){
      alert('Please all fields are required');
      return;
    }
    if(details?.email.indexOf("@") < 0){
    alert('Invalid email format');
    return;
  }

  const results = await requestMaker('aajemail', details)
  if(results?.status === 'successful'){
    isSending(false);
    setToast('Message Sent!. We will contact you shortly.')
    }else {
    isSending(false);
    alert(`${results?.data}`);
    } 
  }

  const handleKeyPressNumberOnly = (event) => {
  const keyCode = event.keyCode || event.which;
  // Check if the entered key is not a number
  if (keyCode < 48 || keyCode > 57) {
    // Prevent the key from being entered
    event.preventDefault();
  }
  };

  const whatsapp =()=> {
  window.open('https://api.whatsapp.com/send?phone=2348053323987')
  }


  const calendry =()=> {
  window.open('https://calendly.com/adesinajohn/30min')
  }

  return ( 
  <div className="my-mother my-d-none fade-in"  id='contact-us'>
    <div className='my-col-6 p-fixed xs-container bg-black xs-down-10vh off-3 bd-code-1 down-10 my-bottom-50 co'>
    <div className="bottm-bd">
      <span className='close-btn faded down-2' onClick={()=> {closeModal('contact-us'); setContact(false)}}><i className='fas fa-times'></i></span>
    </div>
      <div className="my-col-10 xs-10 xs-off-1  xs-down-10 off-1">
      <div className="my-col-12 down-5 xs-centered">
      <div className="my-mother faded bold px20">GET IN TOUCH WITH US</div>
      {!contact && <div className='my-mother down-1'><span className='faded px10'>Please select from any of our contact options ?</span></div>}
    </div>
      <div className="my-mother down-1">
      {!contact &&  <div className='my-col-10 xs-centered down-2 fade-in'>
        <div className='my-col-3 xs-6 xs-down-10 c-pointer '>
        <a href="tel:08053323987">
        <div className='px20 faded'><AiOutlinePhone/></div>
        <span className='px10 faded'>Place a Call</span>
        </a>
        </div>
        <div className='my-col-3 xs-6 xs-down-10 c-pointer' onClick={()=> {setContact('email')}}>
        <div className='px20 faded'><AiOutlineMail/></div>
        <span className='px10 faded' >Send Email</span>
        </div>
        <div className='my-col-3 xs-6 xs-down-10 c-pointer' onClick={whatsapp}>
        <div className='px20 faded'><AiOutlineWhatsApp/></div>
          <span className='px10 faded'>Whatsapp Chat</span> 
        </div>
        <div className='my-col-3 xs-6 xs-down-10 c-pointer' onClick={calendry}>
        <div className='px20 faded'><AiOutlineLaptop/></div>
          <span className='px10 faded'>Schedule Session</span> 
        </div> 
      </div> }
      {contact === 'email' && <div className='my-col-8 fade-in xs-down-10'>
      <div className='px13 my-mother faded-3'> <span className='faded bold'>  <i className='fas fa-angle-left pd-30 c-pointer' onClick={()=> {setContact(false)}}></i> Send Us a Mail</span> <br /> <span className='px10 pd-30 faded'>We give swift responce...</span> </div>
      <div className="my-mother"><input value={details?.fullname} onChange={(e)=> (setDetails(prev => ({...prev, fullname:e.target.value})))}  type="text" className="input"  placeholder="FUllNAME"/></div>
      <div className="my-mother"><input value={details?.email} onChange={(e)=> (setDetails(prev => ({...prev, email:e.target.value})))}  type="email" className="input"  placeholder="EMAIL ADDRESS"/></div>
      <div className="my-mother"><input onKeyPress={handleKeyPressNumberOnly}  value={details?.phonenumber} onChange={(e)=> (setDetails(prev => ({...prev, phonenumber:e.target.value})))}  type="text" className="input"  placeholder="PHONE NUMBER"/></div>
      <div className="my-mother"><textarea value={details?.message} onChange={(e)=> (setDetails(prev => ({...prev, message:e.target.value})))} className="textarea" placeholder="A DESCRIPTION OF PLOT NEEDED"></textarea></div>
      <div className='col-5 top-2 px13'><button className='btn-explore button' onClick={HandleSubmitMessage}>Send <i className='fas fa-paper-plane'></i></button></div>
      {sent &&  <div><span className='faded px13'>Message sent succesfully. We will respond ASAP. Thanks ✨.</span></div>}
      </div>
      }
      </div>
    <div className="my-mother down-5 faded xs-centered xs-down-10">
    <a href="https://www.linkedin.com/company/adesinaadedejirealty/"><span className="pd-10"><i className="fab fa-linkedin"></i></span></a>
    <a href="https://linktr.ee/adesinaadedejijohn"><span className="pd-10"><i className="fa fa-podcast"></i></span></a>
    <a href="https://twitter.com/aajrealty"><span className="pd-10"><i className="fab fa-twitter"></i></span></a>
    <a href="https://instagram.com/adesinaadedejijohn"><span className="pd-10"><i className="fab fa-instagram"></i></span></a>
    </div>
    </div>
      </div>
    </div>
    );
  }
  
  export default OurOffers;