import { AiOutlineWechat} from 'react-icons/ai'
import { useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import useUtils from "../utils/useutiles";
const Nav = ({active}) => {
  const history = useHistory(0)
  const {openModal, closeModal} = useUtils()
  const [navBackground, setNavBackground] = useState(false);
  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.pageYOffset;
      if (scrollPosition > 50) {
        setNavBackground(true);
      } else {
        setNavBackground(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (<>
    {/* <OurOffers/> */}
    <span className="call-us-btn bg-black b-shadow fa-shake" title="Call Us" onClick={()=> {openModal('contact-us')}}><AiOutlineWechat/></span>
  <div className="mobile-nav-full fade-in hidden-ls" id="openModal" >
    {/* <div className="xs-2 right xs-down-10vh faded p-"><span><i className="fas fa-times"></i></span></div> */}
    <span className="my-closebtn" onClick={()=>{closeModal('openModal')}}><i className="fas fa-times faded"></i></span>
    <div className="xs-10  link-con">
    <span className="links xs-down-10vh" onClick={()=> {history.push('/')}}>HOME</span>
    <span className="links" onClick={()=> {history.push('/offers')}}>INVESTMENT</span>
    <span className="links" onClick={()=> {history.push('/about')}}>ABOUT</span>
    <span className="links" onClick={()=> {history.push('/projects')}}>OUR PROJECTS</span>
    <span className="links" onClick={()=> {history.push('#')}}>Blog</span>
    <span className="links" onClick={()=> {history.push('ouroffers')}}>GET IN TOUCH</span>
    </div>
  </div>


  <div className={`${navBackground ? 'mobile-nav bd-bottom bg-black hidden-ls' : 'mobile-nav hidden-ls'}`}>
    <div className="my-logo hidden-xs"></div>
    <div className="my-logo bg-fa hidden-ls"></div>
    <div className="xs-container xs-down-6"><i className="pd-30 fl-right  faded fas fa-bars px30" onClick={()=> {openModal('openModal')}}></i></div>
  </div>

    <nav  className={`${navBackground ? 'nav-on-scroll hidden-xs' : 'hidden-xs'}`}>
      <div className="my-logo"></div>
        <span className={`links ${active === 'home' && 'active'}`} onClick={()=> {history.push('/')}}>HOME</span>
        <span className={`links ${active ==='offers' && 'active'}`} onClick={()=> {history.push('/offers')}}>OUR OFFERS</span>
        <span className={`links ${active ==='about' && 'active'}`} onClick={()=> {history.push('/about')}}>ABOUT</span>
        <span className={`links ${active ==='projects' && 'active'}`} onClick={()=> {history.push('/projects')}}>OUR PROJECTS</span> 
        <span className="links" onClick={()=> {history.push('#')}}>Blogs</span>   
        <span className="links down-1" onClick={()=> {history.push('/ouroffers')}}>GET IN TOUCH</span>
      </nav>
  </> );
  }
  
  export default Nav;