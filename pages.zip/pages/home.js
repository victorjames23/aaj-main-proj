import deo from "../videos/pexels-david-mcbee-4770380-1920x1080-30fps.mp4"
import { useEffect, useRef, useState } from "react";
import { useHistory } from "react-router-dom";
import Nav from "../components/nav";
import {AiOutlineArrowDown, AiOutlineHeatMap, AiOutlineLock, AiOutlineMail, AiOutlinePhone, AiOutlineWechat} from 'react-icons/ai'
import logo from "../images/1.jpg"
import logo1 from "../images/2.jpg"
import logo2 from "../images/3.jpg"
import OurOffers from "../components/ouroffers";
import Layout from "../components/layout";
import Fade from  'react-reveal/Fade'
import SiteLayout from "../components/sitelayout";
import Footer from "../components/footer";
import useUtils from "../utils/useutiles";

const Home = () => {
  const history = useHistory(0)
  const divRef = useRef(null);
  const vidRef = useRef(null);
  const {openModal} = useUtils();
  const [currentTime, setCurrentTime] = useState(0);

  // useEffect(() => {
  //  vidRef.current.play();
  // });


  const handleClick = () => {
  divRef.current.scrollIntoView({ behavior: 'smooth' });
  };

  const calendry =()=> {
  window.open('https://calendly.com/adesinajohn/30min')
  }

  return ( 
    <div className="">
    <div className="bg-video-con">
    <div className="scarf-2">
      <Nav active='home'/>
      <div className="my-col-10 xs-10 xs-off-1 xs-down-15vh off-1 down-8">
        {/* <Fade bottom> */}
      <div className="hidden-ls d xs-down-6vh centered">
        <div><span className="alice px20 pdl-20">Let's Help You</span></div>
        <div className="mother xs-top-2"><span className="xs-px50 bold alice">INVEST WITH THE 1%</span></div>
        
        <div className="alice my-col-8 xs-12 xs-px20 xs-top-2">With Real Estate Value- investing </div>
        {/* </Fade> */}
        <div className="my-mother down-3 xs-down-10"><span className="btn-explore alice" onClick={()=> {openModal('ouroffers')}}>GET STARTED</span></div>
      </div>

        {/* <Fade bottom>  */}
        <div className="down-6 bold hidden-xs centered">
          <div className="my-mother"><span className="alice px20 monR">...Let's Help You</span></div>
          <div className="my-mother top-1"><span className="alice px80" ><span className="colo-code-3">RETIRE EARLY</span> </span></div>
          <div className="alice px50 top-1 my-mother">With  Real Estate Value-investing.</div>
        {/* <div className="my-mother"><span className="alice px20" >With Real Estate Value-investing</span></div> */}
        <div className="my-mother down-3 xs-down-10 hidden-xs"><span className="btn-explore alice" onClick={()=> {openModal('contact-us')}}>START NOW</span></div>
        </div>
        {/* </Fade> */}
      </div>
    </div>
    </div>
    <div className="d bg-black faded"  ref={divRef}>
      <div className="my-container xs-10 xs-off-1 bg-black">
      <div className="my-col-10 off-1 centered down-5 xs-down-10">
      <Fade bottom>
      <div className="my-col-12 xs-container down-3">
        <div className="my-col-12 xs-12 xs-down-10"><span className="px60 xs-px40 faded bold">Current Investment</span></div>
        <div className="my-mother down-5 xs-down-10"> <span className="px30 xs-px20 faded bold">THE WORLD’S FIRST TRUE <br/> PAN-AFRICAN EXPERIENCE RESORT</span></div>
        </div>
      </Fade>
      <div className="hidden-xs down-5 d">
        <div className="my-mother centered xs-down-10  down-5"> <span className="px20 bold">OUR SITE LAYOUTS</span></div>
        <div className="my-mother xs-down-3 centered px13 down-1">ONLY 20 PLOTS AVAILABLE !</div>
        </div>
      <div className="my-mother down-3 hidden-xs">
        <div className="my-col-4 xs-12">
        <div className="my-card-2 my-bottom-10">
        <div className="z-unset dark-scarf"></div>
          <div className="my-img-container">
          <img src={logo} alt="" /></div>
          <div className="my-col-10 off-1">
          <span className="px13 bold">View 1</span>
          <div className="my-mother down-2 top-bodered"><span className="px13 faded">Layout front view</span></div>
          </div>
        </div>
        </div>
        <div className="my-col-4 xs-12">
        <div className="my-card-2 my-bottom-10">
          <div className="z-unset dark-scarf"></div>
          <div className="my-img-container"><img src={logo1} alt="" /></div>
          <div className="my-col-10 off-1">
          <span className="px13 bold">View 2</span>
          <div className="my-mother down-2 top-bodered"><span className="px13 faded">Layout Top view</span></div>
          </div>
        </div>
        </div>
        <div className="my-col-4 xs-12">
        <div className="my-card-2 my-bottom-10">
          <div className="z-unset dark-scarf"></div>
          <div className="my-img-container">
          <img src={logo2} alt="" /></div>
          <div className="my-col-10 off-1">
          <span className="px13 bold">View 3</span>
          <div className="my-mother down-2 top-bodered"><span className="px13 faded">Layout Side view</span></div>
          </div>
        </div>
        </div>
      </div>
      <Fade bottom>
      <div className="my-mother down-3 xs-down-10">
        <div className="hidden-ls">
        <div className="my-mother centered xs-down-10  down-5"> <span className="px20 bold">OUR SITE LAYOUTS</span></div>
        <div className="my-mother xs-down-3  centered px13 hidden-ls">ONLY 20 PLOTS AVAILABLE !</div>
        </div>
        <div className="my-mother xs-down-6 hidden-ls"><SiteLayout/></div>
        <div className="my-col-10 off-1 down-2 xs-down-15 xs-container"><span className="faded">50% LIMITED PRE-LAUNCH OFFER (RESIDENTIAL). All Fees included. No Hidden or extra fees.</span></div> 
        <div className="my-mother xs-down-5 down-2 faded centered">OFFER AVAILABLE TILL JUNE 30<sup>th</sup> !</div>
      </div>
      </Fade>
      <div className="my-mother xs-down-10 down-3"><span className="btn-explore white" onClick={()=>{openModal('Contact')}}>GET STARTED !</span></div>
      <div className="xs-12 xs-down-15vh hid my-col-8 off-2 down-8"><Layout/></div>
      </div>
      </div>
      <div className="bg-landing-2 my-mother xs-down-10 bg-color-code-3 down-4">
        <div className="scarf-2 ">
        <div className="my-col-10 xs-10 xs-off-1 off-1 down-6 xs-down-10vh">
        </div>
        </div>
      </div>
    </div> 
    <Footer/>
    </div>
  );
  }
  
  export default Home;