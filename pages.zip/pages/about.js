import Nav from "../components/nav";
import deo from "../videos/pexels-david-mcbee-4770380-1920x1080-30fps.mp4"
import { useEffect, useRef, useState } from "react";
import { useHistory } from "react-router-dom";
import aaj from "../images/aaj.jpg"
import {AiOutlineArrowDown, AiOutlineHeatMap, AiOutlineLock, AiOutlinePhone} from 'react-icons/ai'
import OurOffers from "../components/ouroffers";
import Layout from "../components/layout";
import Fade from  'react-reveal/Fade'
import SiteLayout from "../components/sitelayout";
import Footer from "../components/footer";

const About = () => {
  const history = useHistory(0)
  const divRef = useRef(null);
  const vidRef = useRef(null);
  const [currentTime, setCurrentTime] = useState(0);

  
  const handleClick = () => {
  divRef.current.scrollIntoView({ behavior: 'smooth' });
  };

  const calendry =()=> {
  window.open('https://calendly.com/adesinajohn/30min')
  }

  return ( <>
    <OurOffers/>
  <div className="bg-video-con">
    <div className="scarf-2">
  <Nav active='about'/>
  <div className="my-col-10 off-1 xs-10 xs-off-1 down-10 xs-down-10vh">
  <Fade bottom>
  <div className="my-col-8 down-6 xs-12 xs-down-8vh hidden-ls"><span className="faded px60 xs-px50 bold"> <span className="">THE</span> AAJ STORY</span></div>
  <div className="my-col-8 down-6 xs-12 xs-down-5 hidden-xs"><span className="faded px60 xs-px40 bold"> <span className="xs-px13">THE</span> <br  className="hidden-ls"/> ADESINA ADEDEJI JOHN STORY</span></div>
  </Fade>
  <Fade bottom >
  <div className="my-col-7"><span className="faded px13"> Adesina Adedeji John is a convergence of forward thinking, visionary and innovative individuals and teams burdened to create ....</span></div>
  </Fade>
  <Fade bottom >
    <div className="my-mother down-2 xs-down-5"><span className="btn-explore white" onClick={handleClick}>READ MORE</span></div>
  </Fade>
  </div>
    </div>
  </div>
  <div className="my-mother my-bottom-50">
    <div className="my-col-10 off-1 down-10 xs-10 xs-off-1 xs-down-20" ref={divRef}>
  <div className="my-col-12">  <div className="my-col-10 xs-centerd"><span className="faded px50 xs-px40 bold">THE ADESINA ADEDEJI JOHN STORY</span></div></div>
    <div className="my-col-4 down-3 off-1 hidden-ls xs-down-5"><div className="my-img-container"><img src={aaj} alt="" /></div></div>
    <div className="my-col-6 xs-12 xs-down-10 down-3 monR px13 faded">
    <p>Adesina Adedeji John is a convergence of forward thinking, visionary and innovative individuals and teams burdened to create masterpieces from Africa for the global market. Using real estate as a tool, we are combining experiences to contribute to Infrastructural investment, development and management across our host country, Nigeria and Africa at large. Though creating locally, the global scene is our playground. Hence, we always seek to create products that serve a global need, with Africa as priority.</p>
    <p>Led by Opeyemi  Adesina,  Abiodun Adedeji and Samuel John,  CHANZO is our model project to project Africa in a new and deserved light as a result of the gross incomplete or total misrepresentation of the African culture across several countries globally. We prioritize employing, equipping and grooming young African talents to work on our projects. We can’t claim to be forward thinking without fuelling our initiatives with fresh minds. Before this decade ends, the name Adesina  Adedeji John will be forever written in the sands of time.</p>
    </div>
    <div className="my-col-4 down-3 off-1 hidden-xs"><div className="my-img-container"><img src={aaj} alt="" /></div></div>
    <div className="my-mother down-5">
    <div className="my-mother xs-down-1"><span className="faded bold">About Us</span></div>
    <p className="faded px13 xs-down-2 my-mother">We are committed to growing local economies with viable real estate.</p>
  </div>
    <div className="my-mother">
    <div className="my-mother xs-down-1"><span className="faded bold">Vision</span></div>
    <p className="faded px13 xs-down-2 my-mother">To be the largest contributor to the global economy.</p>
  </div>
    <div className="my-mother">
    <div className="my-mother xs-down-1"><span className="faded bold">Current Goal</span></div>
    <p className="faded px13 xs-down-2 my-mother">
    To increase Nigeria’s GDP by 25% with over N100B investment contribution to the economy by 2030.</p>
  </div>
  <div className="my-mother">
    <div className="my-mother xs-down-1"><span className="faded bold">Mission</span></div>
    <p className="faded px13 xs-down-2 my-mother">
  - To discover and harness viable local economic opportunities in our host communities
  <br />
  - To facilitate cross-sectoral development through sustainable partnerships
  <br />
  - To empower local communities with economic arsenals to thrive sustainably
    </p>
  </div>
  <div className="my-mother">
    <div className="my-mother xs-down-1"><span className="faded bold">Core Values</span></div>
    <p className="faded px13 xs-down-2 my-mother">
  - Excellence
  <br />
  - Audacity
  <br />
  - Honor
    </p>
  </div>
  
    </div>
  </div>
  <div className="bg-landing-2 my-mother xs-down-10 bg-color-code-3 down-4">
        <div className="scarf-2 ">
        <div className="my-col-10 xs-10 xs-off-1 off-1 down-6 xs-down-10vh">
        <div className="my-col-5 down-4"> <div><span className="px50 xs-px30 bold faded">SPEAK WITH A LEAD INVESTOR.</span></div></div>
        <div className="my-col-4 off-2 xs-12 xs-down-5">
          <div><span className="px30 faded xs-px20">Schedule an online session today</span></div>
          <div> <div className="btn-explore down-10 xs-down-10 faded xs-px10" onClick={calendry}>CLICK TO MEET</div></div>
        </div>
        </div>
        </div>
      </div>
  <Footer/>

  </> );
  }
  
  export default About;