import Slider from "react-slick";
import logo from "../images/1.jpg"
import logo1 from "../images/2.jpg"
import logo2 from "../images/3.jpg"
const SiteLayout = () => {
 const settings = {
  dots: true,
  infinite: true,
  speed: 500,
  slidesToShow:1,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 3000,
  pauseOnHover: true // prevent pausing on hover
};
 return ( <>
 <Slider  {...settings}>

  <div className="xs-centered">
   <div className="my-card-2 my-bottom-10">

    <div className="img-container">
    <div className="dark-scarf z-unset"></div>
     <img src={logo} alt="" /></div>
    <div className="xs-container xs-down-2 ">
     {/* <span className="px13 bold">View 1</span>
     <div className="my-mother xs-down-4 top-bodered"><span className="px13 faded-3">Layout front view</span></div> */}
    </div>
   </div>
  </div>
  <div className="">
   <div className="my-card-2 my-bottom-10">
   <div className="dark-scarf z-unset"></div>
    <div className="img-container"><img src={logo1} alt="" /></div>
    <div className="xs-container xs-down-2 off-2 ">
     {/* <span className="px13 bold">View 1</span>
     <div className="my-mother xs-down-4 down-2 top-bodered"><span className="px13 faded-3">Layout front view</span></div> */}
    </div>
   </div>
  </div>
  <div className="">
   <div className="my-card-2 my-bottom-10">
   <div className="dark-scarf z-unset"></div>
    <div className="img-container"><img src={logo2} alt="" /></div>
    <div className="xs-container xs-down-2 off-2 ">
     {/* <span className="px13 bold">View 1</span>
     <div className="my-mother xs-down-4 down-2 top-bodered"><span className="px13 faded-3">Layout front view</span></div> */}
    </div>
   </div>
  </div>

 </Slider>
 </> );
}
 
export default SiteLayout;